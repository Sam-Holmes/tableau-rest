from tableau_rest import Tools
import requests  # Contains methods used to make HTTP requests
import xml.etree.ElementTree as ET  # Contains methods used to build and parse XML


def get_favs(user):
    pass


def add_datasource(datasource):
    pass


def add_view(view):
    pass


def add_workbook(workbook):
    pass


def delete_datasource(datasource):
    pass


def delete_view(view):
    pass


def delete_workbook(workbook):
    pass
